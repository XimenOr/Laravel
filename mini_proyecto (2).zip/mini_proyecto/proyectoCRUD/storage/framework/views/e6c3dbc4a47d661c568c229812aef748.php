<!-- Modal -->
<div wire:ignore.selt class="modal fade" id="addStudentModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel"><i>Añadir Victima</i></h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <form>
            <div class="form-group">
                <label for="firtname"><i>Nombre</i></label>
                <input type="text" name="firstname" class="form-control" wire:model="firstname" />
            </div>
            <div class="form-group">
                <label for="lastname"><i>Apellido</i></label>
                <input type="text" name="lastname" class="form-control" wire:model="lastname" />
            </div>
            <div class="form-group">
                <label for="email"><i>Descripcion</i></label>
                <input type="text" name="email" class="form-control" wire:model="email" />
            </div>
            <div class="form-group">
                <label for="phone"><i>Lugar</i></label>
                <input type="text" name="phone" class="form-control" wire:model="phone" />
            </div>
        </form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal"><i>Cerrar</i></button>
        <button type="button" class="btn btn-success" data-bs-dismiss="modal" wire:click.prevent="store()"><i>Añadir Victima</i></button>
      </div>
    </div>
  </div>
</div><?php /**PATH C:\proyectoCRUD\resources\views/livewire/create.blade.php ENDPATH**/ ?>